
print('hi, this my test code')

a =111
print(a,end='\t')

print(100)


##input
a = input('enter num :') #default input is str 
b = input('enter num :')

print(type(a))
print(type(b))

#type casting / convert str to int before addition
a = int(a)
b = int(b)


print(type(a))
print(type(b))


c =a+b
print(c)


