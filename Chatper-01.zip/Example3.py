
a =111
b =44


if a>b:
     print('a is greater ')
     print(a)

else:
     print('b is greater')
     print(b)
     
