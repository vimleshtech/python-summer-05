a = int(input('enter num :')) #default input is str 
b = int(input('enter num :'))
c =a+b
print(c)

