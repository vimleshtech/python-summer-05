eid =101 #int
name ='Nitin Sharma' #stre
age = 24 #int

'''
print('employee id is :',eid)
print('name is  ', name)
'''

print('Age = ',age)




