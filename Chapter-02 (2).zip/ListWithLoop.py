data = [111,222,333,444,54]

#wap to get count of even no
ec =0
for a in data: # iterate (read one by one and store on given variable)
     print(a)
     if a % 2 ==0:
          ec =ec+1


print(ec)

#
a =['Nitin','Jatin','Ayush']
b =[50,56,90]

for i in range(0,len(a)):

     print(a[i],b[i])
     


##
a= [] #empty 
for i in range(1,10): #loop from 1 to 9
     d = input('enter data :') #input
     a.append(d)  #append

print(a)








     







     
