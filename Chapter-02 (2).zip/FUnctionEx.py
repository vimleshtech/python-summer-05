#create function
#no argument no return 
def test():
     print('hello,test')

#no argument no return 
def add():
     a =int(input('enter data :'))
     b =int(input('enter data :'))
     c =a+b
     print(c)

#no argument with return
def get_input():
     x = int(input('enter  - getinput data :'))
     y = int(input('enter  - getinput data :'))
     return x,y
             

#argument with no return
def addnum(a,b):
     c =a+b
     print(c)
#argument with return
def subnum(a,b):
     c =a-b
     return c




add()
test()
add()

m,n= get_input()
print(m*n)
print(m/n)


addnum(m,n)
addnum(m,1000)
addnum(111111,44444)


o = subnum(11,22)
print(o)
print(o+100)




