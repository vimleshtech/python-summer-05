
a =input('enter string  :')

print(a.title()) #convert to proper case


###

a = 'this IS Python code'

o = list(a)
i =0
while i<len(o):

     if o[i].islower():
          print(o[i].upper(),end='')
     else:
          print(o[i].lower(),end='')
     i=i+1






