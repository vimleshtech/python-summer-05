a= [[1,23,4],[444,555,66]]

print(a)
print(a[0])
print(a[0][1])


#for
for r in a:
     #print(r)
     for c in r:
          print(c)
          
     
