

a =[111,2222,333,444,55]

print('max value :',max(a))
print('min value :',min(a))
print('sum value :',sum(a))
print('count :',len(a))


a.append(300)
print(a)

a.pop() #remove from last
print(a)



a.insert(1,34)
print(a)

a.remove(34)
print(a)


a.sort()
print(a)


print(a[1:4])
print(a[-1]) #last value
#print in reverse
print(a[::-1])





