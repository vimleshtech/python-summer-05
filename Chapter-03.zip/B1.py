marks = int(input('enter mark :'))

if marks>40:
     print('pass')
else:
     print('fail')

     
          
          
