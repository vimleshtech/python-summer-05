#-function with default argument
def add(a=0,b=0,c=0,d=0):
     c =a+b+c+d
     print(c)



add()
add(22)
add(11,333)
add(11,333,444)
add(11,333,444,555)


#-function with dynamic argument (arbtery argument)
def mul(*a):
     m  =1
     for x in a:
          m = m*x

     print(m)


mul(111)
mul(111,44444,4444,555,666)
mul(111,44444,4444,555,666,555,4333,555,666,4)




#-recusseive function :function will call to itself
def fact(x):
     if x==1:
          return x
     else:
          return x*fact(x-1)

o = fact(6)
print(o)




#-lambda function : one line or single line function 

x = lambda m : m+1

'''
def x(m):
     m = m+1
     return m
'''
print(x(5))

#-function inside function / nested function
def test():
     print('before')
           
     def ab():
          print('inside')

          
          
     ab()
     print('after')



test()







     



     


     



