#-argument with return
def add(a,b):
     c =a+b
     print('output is ',c)
     
#-argument with no return
def sub(a,b,c):
     d =a-b-c
     return d

def tax(amt):
     t = 0
     if amt>10000:
          t = amt*.10
     else:
          t = amt*.05

     return t
