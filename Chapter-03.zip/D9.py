
a = []

#input in list a
for i in range(0,5):
     d = int(input('enter  data  for a:'))
     a.append(d)

print(a)

ind = int(input('enter index for rotation :'))

b = a[0:ind]
a[0:ind] =  []

for x in b:
     a.append(x)

print(a)

  

