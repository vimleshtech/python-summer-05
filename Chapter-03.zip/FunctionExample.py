#-no argument no return
def wel():
     print('this is test function ')
     print('this file contains wel, add, sub, mul functions ')
     
#-no argument with return
def gettime():
     a = input('etner data :')
     return a
          
#-argument with return
def add(a,b):
     c =a+b
     print('output is ',c)
     
#-argument with no return
def sub(a,b,c):
     d =a-b-c
     return d
     
#call to function
wel()
wel()

o  =  gettime()
print(o)

#call with argument  / parameter 
add(11,233)


o = sub(11,22,4)
print(o)








