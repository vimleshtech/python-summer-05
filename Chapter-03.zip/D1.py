
marks = []
for i in range(1,11): # from 1 to <11

     m = int(input('enter mark '))
     marks.append(m)



print(marks)

     
