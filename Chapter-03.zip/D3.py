
a = []
b = []

#input in list a
for i in range(0,5):
     d = int(input('enter  data  for a:'))
     a.append(d)


#input in list b
for i in range(0,5):
     d = int(input('enter data for b:'))
     b.append(d)



##subtract
for i in range(0,len(a)):
     print(a[i] - b[i])
     
     
#

     
