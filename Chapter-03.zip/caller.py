#caller

#import library  / module #1

import mylib

mylib.add(111,22)
out = mylib.tax(334444)
print(out)



#2
from mylib import *
add(11,23)

#3 import module and create alias 
import mylib as a
a.add(11,3)


#import selected functions 
from mylib import add,tax
add(11,3)
tax(444)
