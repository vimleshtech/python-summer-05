a = []

#input in list a
for i in range(0,5):
     d = float(input('enter  data  for a:'))
     a.append(d)

print('output in rev :',a[::-1])
